import React, { useState } from "react";

const Tab = (props) => {
  // console.log(props);

  const [selectedTab, setSelectedTab] = useState(props.items[1]);

  return (
    <div>
      <header>
        {props.items.map((item, i) => {

          return (
            <h3 style = {{display: 'inline-block', margin: '30px'}} onClick={(e) => {setSelectedTab(item)}} key={i}>
              {item.header}
            </h3>
          );
        })}
      </header>
      <div>
        <p style = {{marginLeft: '30px'}}>{selectedTab.content}</p>
      </div>
    </div>
  );
};

export default Tab;


// <div style = {{display: 'inline-block', margin: '10px'}}>
// <p style = {{'background-color': box.color, height: '100px', width: '100px'}}></p>