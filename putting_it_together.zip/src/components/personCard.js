import React, { Component } from 'react';

// 1. Create a class, must start with capital letter
// 2. Extend React.Component
// 3. Use render method a React Element with either JSX or React.createElement()
// 4. Pass props (properties) down to child components by adding html attribute to component
    // --> Each attribute becomes key in props object and each value given to attribute becames value of that key
    // ------> To acces props in Class Component, use keyword "this," because we are extending React.Component (this.props.____)
class PersonCard extends Component {
    constructor(props) {
        // call constructor of our parent class
        super(props);
        this.state = {
            age: this.props.age
            }
            // React tries to treat state as if it's immutable, thus anything that can be manipulated is put into state to handle current state
    }

    birthdayHandler = () => {
        this.setState({
            age: this.state.age +1
        })
    }
    // methods always go below the constructor

    render() {
        return(
            <div>
                <h2>{ this.props.lastName }, { this.props.firstName }</h2>
                <p>Age: { this.state.age }</p>
                <p>Hair Color: { this.props.hairColor }</p>
                <button onClick = { this.birthdayHandler } > Birthday Button for {this.props.firstName} {this.props.lastName}
                </button>
                {/* Remember to camelCase JS events in React */}
            </div>
        )
    }
}

export default PersonCard;