// const ninja1 = new Ninja("Hyabusa");
// ninja1.sayName();
// ninja1.showStats();

class Ninja {
    constructor(name, health, speed = 3, strength = 3){
    this.name = name;
    this.health = health;
    this.speed = speed;
    this.strength = strength;
    }
    sayName() {
        console.log(this.name);
        // print ninja's name
    }
    showStats() {
        console.log(this.all)
        // print all stats associated with instance of ninja
    }
    drinkSake(){
        this.health += 10
        // method that adds 10 health to instance of Ninja
    }
}

class Sensei extends Ninja {
    constructor (name, health = 200, speed = 10, strength = 10){
        super(name, health, spped, strength);
    this.wisdom = 10;
    }
    speakWisdom(){
        // speakWisdom function  call drinkSake method from Ninja class
        super.drinkSake();
        console.log("A wise message")
    }
}