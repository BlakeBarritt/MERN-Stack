// const ninja1 = new Ninja("Hyabusa");
// ninja1.sayName();
// ninja1.showStats();

class Ninja {
    constructor(name, health, speed = 3, strength = 3){
    this.name = name;
    this.health = health;
    this.speed = speed;
    this.strength = strength;
    }
    sayName() {
        console.log(this.name);
        // print ninja's name
    }
    showStats() {
        console.log(this.all)
        // print all stats associated with instance of ninja
    }
    drinkSake(){
        this.health += 10
        // method that adds 10 health to instance of Ninja
    }
}