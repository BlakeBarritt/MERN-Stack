class Card {
    constructor(name, cost) {
        this.name = name;
        this.cost = cost;
    }
}

class Unit extends Card {
    constructor(name, cost, power, res) {
        super(name, cost);
        this.power = power;
        this.res = res;
    }

    attack(target) {
        // reduce target res by power
        target.res -= this.power
        // play( target ) {
        //     if( target instanceof Unit ) {
        //         // implement card text here
        //     } else {
        //         throw new Error( "Target must be a unit!" );
        //     }
        // }
    }
}

class Effect extends Card {
    constructor(name, cost, text, stat,magnitude) {
        super(name, cost);
        this.text = text;
        this.stat = stat;
        this.magnitude = magnitude;
    }

    play(target) {
        // modifies ninja
        target.res += this.magnitude
        // play( target ) {
        //     if( target instanceof Unit ) {
        //         // implement card text here
        //     } else {
        //         throw new Error( "Target must be a unit!" );
        //     }
        // }
    }
}

const redBelt = new Unit("red belt ninja", 3, 3, 4);
const blackBelt = new Unit("black belt ninja", 4, 5, 4);
console.log(redBelt);
console.log(blackBelt);

const hardAlgo = new Effect("Hard Algo", 2, "increase target resilience by 3", "res", 3);
const unhandledPromReject = new Effect("Unhandled Promise Rejection", 1, "reduce target's res by 2", "res", -2)
const pairProgram = new Effect("Pair Programming", 3, "increaes target power by 2", "power", 2);

// Play hard algo on red belt ninja
hardAlgo.play(redBelt);
// play unhandled promise on red belt ninja
unhandledPromReject.play(redBelt);
// play pair programming on red belt ninja
pairProgram.play(redBelt);
// have red belt ninja attack black belt ninja
redBelt.attack(blackBelt);
