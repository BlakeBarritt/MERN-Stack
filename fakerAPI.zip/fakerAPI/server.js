const express = require("express");
const app = express();
const port = 8000;
const faker = require("faker");


class Person {
    constructor() {
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.jobTitle = faker.name.jobTitle();
        this.vehicle = faker.vehicle.vehicle();
    }
}
console.log(new Person());


class Company {
    constructor(){
        this.name = faker.company.companyName();
        this.street = faker.address.streetName();
        this.city = faker.address.city();
        this.state = faker.address.state();
        this.country = faker.address.country();
    }
}
console.log(new Company());

app.get("/api/person/new", (req, res) => {
    var user = new Person();
    res.json({
        results: user
    });
})

app.get('/api/companies/new', (req,res) =>{
    var company = new Company();
    res.json({
        results: company
    });
    
})

app.get('/api/user/company', (req, res) =>{
    var user = new Person();
    var company = new Company();
    res.json({
        results: {
            user: user,
            company: company,
        }
    })
})



app.get("/api", (req, res) => {
    res.json({message: "it's running"})
})

app.listen( port, () => console.log(`Listening on port: ${port}`) );


