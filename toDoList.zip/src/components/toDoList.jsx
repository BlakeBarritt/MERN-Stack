import { useState } from 'react';

function ToDoList () {
    const [Task, setTask] = useState("");
    const [list, setList] = useState([]);

    function handleChange(event) {
        setTask(event.target.value);
        // same as inline in the form
    }

    function handleSubmit(event) {
        event.preventDefault();
        // event.preventDefault() prevents the page from refreshing (HTML form submit)
        const clonedList = list.slice();
        // Add item to list by creating a "shallow copy"
        clonedList.push({
            text: Task,
            completed: false
        // building out cloned list
        });
        setList(clonedList);

        setTask("");
        // so the previously entered text doesn't stay in bar
    }

    function handleDelete(i) {
        const filter = list.filter((task, index) => i !== index);

        setList(filter); 
    }

    function lineThrough (i) {
        const item = list[i];
        if (item.completed === true){
            item.completed = false;
        }
        else {
            item.completed = true;
        }
        setList([...list]);
    }

    return (
        <div>
            {Task}
            <form onSubmit = {handleSubmit}>
                <input 
                    type="text"
                    onChange = {handleChange}
                    value = {Task}

                />
                <button>Add</button>
            </form>
            <br/>
            <div>
                {list.map((task, index) => (
                    <p key = {index}>
                        <span
                        style = {{textDecoration: task.completed ? "line-through" : "none"}}> {task.text}
                        {/* Asking is the task completed. If yes, line through, if not none */}
                        </span>
                        <input type="checkbox" onChange={() => lineThrough(index)}/>
                        {/* callback function calls handle line through, which has access to index*/}
                        <button onClick = {() => handleDelete(index)}>Delete</button>    
                        {/* callback function calls handle delete, which has access to index*/}
                    </p>
                ))}
            </div>
        </div>
    )
}

export default ToDoList;