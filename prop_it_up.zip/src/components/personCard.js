import React, { Component } from 'react';

// 1. Create a class, must start with capital letter
// 2. Extend React.Component
// 3. Use render method a React Element with either JSX or React.createElement()
// 4. Pass props (properties) down to child components by adding html attribute to component
    // --> Each attribute becomes key in props object and each value given to attribute becames value of that key
    // ------> To acces props in Class Component, use keyword "this," because we are extending React.Component (this.props.____)
class PersonCard extends Component {
    render() {
        return(
            <div>
                <h2>{ this.props.lastName }, { this.props.firstName }</h2>
                <p>Age: { this.props.age }</p>
                <p>Hair Color: { this.props.hairColor }</p>
            </div>
        )
    }
}

export default PersonCard;