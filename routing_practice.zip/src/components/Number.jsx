import React from 'react';

const Number = (props) => {
    if (isNaN(props.number)) return (
        <p>The word is: {props.number}</p>
    )
    else return (
        <p>The number is: {props.number}</p>
    )
    }

    // Couldn't get ternary to work, review with Brendan tomorrow
    // const Number = (props) => {
    //     return (
    //     <>

    //         { isNaN(props.num) ?
    //             <p>The word is: {props.number}</p>
    //         :   <p>The number is: {props.number}</p>
    //         }
    //     </>
    //     )
    // }




export default Number;