import React from 'react';
import './App.css';

import { Router } from '@reach/router';
import Home from './components/Home';
import Number from './components/Number';
import Color from './components/Color'


// Hint: use the isNaN method (is Not a Number). For example: isNaN(+"35") is false, isNaN(+"hello") is true

function App() {
  return (
    <div className="App">
        <Router>
            <Home path="/home"/>
            <Number path="/:number"/>
            {/* <Color path ="/:word"/> */}
            {/* Got lost on creating additional path for word/number, Kelvin helped me with boolean and was awesome! */}
            <Color path="/:word/:color/:background"/>
        </Router>
    </div>
  );
}
export default App;
