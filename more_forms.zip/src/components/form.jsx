// CURRENTLY UNABLE TO GET THIS TO WORK, INSTRUCTED TO MOVE ON, WILL COME BACK TO IT WITH MORE VALIDATION PRACTICE. WATCHED SEVERAL DEMOS ON DIFFERENT WAYS TO ACHIEVE FRONT END VALIDATION

import React, { useState } from  'react';

const Form = (props) => {
    console.log(props);
    const [state, setState] = useState({})
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");  
    const [confirmPassword, setConfirmPassword] = useState("");  

    const [firstNameError, setFirstNameError] = useState({});
    const [lastNameError, setLastNameError] = useState({});
    const [emailError, setEmailError] = useState({});
    const [passwordError, setPasswordError] = useState({});
    const [confirmPasswordError, setConfirmPasswordError] = useState({});


    const onSubmit = (e) => {
        e.preventDefault();
        const isValid = formValidator();
        if(isValid){
            return "success!"
        }
    }

    const formValidator = () => {
        const firstNameError = {};
        const lastNameError = {};
        const emailError = {};
        const passwordError = {};
        const confirmPasswordError = {};
        let isValid = true;

        if (firstName.length < 2){
            firstNameError.firstNameShort = "Field must be at least 2 characters";
            isValid = false;
        }
        if (lastName.length < 2){
            lastNameError.firstNameShort = "Field must be at least 2 characters";
            isValid = false;
        }
        if (email.length < 5){
            emailError.emailShort = "Field must be at least 5 characters";
        }
        if (password.length < 8){
            passwordError.passwordShort = "Field must be at least 8 characters";
        }
        if (confirmPassword !== password){
            confirmPasswordError.passwordsMatch = "Passwords must match";
        }
    }
        
    return(
        <div>
        <form onSubmit = {onSubmit}>

            <div>
                <label htmlFor="firstName">First Name</label> 
                <input 
                    type="text"
                    value = {firstName}
                    onChange={ (e) => setFirstName(e.target.value) } />
                {Object.keys(firstNameError).map((key) => {
                    return <div style = {{color : "red"}}> {firstNameError[key]} </div>
                })}
            </div>
            <div>
                <label htmlFor="lastName">Last Name</label> 
                <input
                    type="text"
                    value = {lastName}
                    onChange={ (e) => setLastName(e.target.value) } />
                {Object.keys(lastNameError).map((key) => {
                    return <div style = {{color : "red"}}> {lastNameError[key]} </div>
                })}
            </div>
            <div>
                <label htmlFor="email">Email Address </label> 
                <input 
                type="text" 
                value = {email}
                onChange={ (e) => setEmail(e.target.value) } />
                {Object.keys(emailError).map((key) => {
                    return <div style = {{color : "red"}}> {emailError[key]} </div>
                })}
            </div>
            <div>
                <label htmlFor="password">Password </label>
                <input 
                type="password"
                value = {password}
                onChange={ (e) => setPassword(e.target.value) } />
                {Object.keys(passwordError).map((key) => {
                    return <div style = {{color : "red"}}> {passwordError[key]} </div>
                })}
            </div>
            <div>
                <label htmlFor="confirmPassword">Confirm Password </label>
                <input 
                type="password" 
                value = {confirmPassword}
                onChange={ (e) => setConfirmPassword(e.target.value) } />
                {Object.keys(confirmPasswordError).map((key) => {
                    return <div style = {{color : "red"}}> {confirmPasswordError[key]} </div>
                })}
            </div>
            <input type="submit" value="Create User" />
        </form>

            <div>
                <p>First Name: {firstName}</p>
                <p>Last Name: {lastName}</p>
                <p>Email: {email}</p>
                <p>Password: {password}</p>
                <p>Confirm Password: {confirmPassword}</p>
            </div>
        </div>
        );
    };

export default Form;