import './App.css';
import React, {useState} from 'react';
import Form from './components/form'

function App() {
  const [state, setState] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
// shorthand form


  return (
    <div className="App">
      <Form inputs={state} setInputs={setState} />

    </div>
  );
}

export default App;