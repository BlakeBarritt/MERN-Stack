const mongoose = require("mongoose");


const JokesSchema = new mongoose.Schema({
    setup: {
        type: String,
        required: [true, "You need to be funny"],
        minlength: [10, "At least 10 characters"],
    },
	punchline: {
        type: String,
        required: [true, "who's there"],
        minlength: [3, "At least 3 characters"]
    },
});

const Joke = mongoose.model("Joke", JokesSchema);

module.exports = Joke;