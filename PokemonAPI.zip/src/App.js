import {useEffect, useState} from 'react';
import Pokemon from './components/Pokemon.jsx'

import "./App.css";


function App() {

  // const[pokemon, setPokemon] = useState([

  // ]);

  // // useEffect(() => {
  //   fetch("https://pokeapi.co/api/v2/pokemon")
  // //     .then(response => {
  // //       return response.json();
  // //     }).then(response => {
  // //       console.log(response);
  // //       setPokemon(response.results);
  // //     }).catch(err=>{
  // //       console.log(err);
  // // });
  // // }, []);

  return (
    <div className="App">
      <Pokemon
      />
    </div>
  );
}

export default App;