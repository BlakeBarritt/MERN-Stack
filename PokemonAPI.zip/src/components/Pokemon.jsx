import React, {useState} from 'react';

function Pokemon () {
    const [characters, setCharacters] = useState([]);

    function Fetch () {
        // instructions to get more than the 20 pokemon imposed limit on API page, if run into same problem going forward.
        fetch("https://pokeapi.co/api/v2/pokemon?limit=1000")
            .then(response => {
                return response.json();
            })
            .then(response => {
                console.log(response);
                setCharacters(response.results);
            })
            .catch(err=> {
                console.log(err);
            })
    }
    return (
        <div>
            <button onClick = {Fetch}>Fetch Pokemon</button>
            <br/>
            {/* Use map to trasnform array of Pokemon from API into an array of list elements <li> with a key reference of it's index value and a display property of their name  */}
            <ul>
            {characters.map((pokemon, index) => (
                <li key = {index}>{pokemon.name}
                </li>
                
            ))}
            </ul>
        </div>
    )
}


export default Pokemon;