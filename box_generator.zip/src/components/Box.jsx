import {useState} from 'react';


const Box = ({box}) => {
    return (
        <span>
            <div style = {{display: 'inline-block', margin: '10px'}}>
                <p style = {{'background-color': box.color, height: '100px', width: '100px'}}></p>
            </div>
        </span>
    )
}

export default Box;