import {useState} from 'react';

const NewBox = ({createBox}) => {

    const [newColor, setNewColor] = useState('');
    const [error, setError] = useState('');

    const submitColor = (event) => {
        event.preventDefault();
        
        let errors = false;
        if (newColor < 3) {
            setError("Must have at least 3 characters")
            errors = true;
        }
        if (!errors) {
            setError(null);
            console.log(newColor);
            createBox({color: newColor})
        }
    }

    return (
        <>
            <form onSubmit = {submitColor}>
                {error}
                <input type="text" value = {newColor} onChange = { e => setNewColor(e.target.value)}/>
                <input type="submit" value="new color!"/>
            </form>
        </>
    )
}

export default NewBox;