import {useState} from 'react';
import Box from './Box';

const Boxes = ({boxes}) => {

    return (
        boxes.map((box, index) =>
            <Box key = {index} box = {box}>

            </Box>

        )
        
    )
}

export default Boxes;