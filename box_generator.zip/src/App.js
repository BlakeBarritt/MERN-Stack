import './App.css';
import React, {useState} from 'react';
import Boxes from './components/Boxes';
import NewBox from './components/newBox';

function App() {

  const [boxes, setBoxes] = useState([
    {color: "red"},
    {color: "blue"},
    {color: "purple"},
  ])

  // write handler adjacent here, pass just the handler
  const createBox = (box) =>{
    setBoxes ([...boxes, box])
    // set previous boxes as all boxes already there + new box being added (accessing setBoxes to update state variable and boxes to read what's in state, pass into return)
  }

  return (
    <div className="App">
      <NewBox createBox = {createBox}/>
      <Boxes boxes = {boxes}/>
    </div>
  );
}

export default App;