import React, {useState} from 'react';
import axios from 'axios';

function Pokemon () {
    const [characters, setCharacters] = useState([]);

    function Fetch () {
        axios.get("https://pokeapi.co/api/v2/pokemon?limit=1000")
        .then(response => setCharacters(response.data.results))
        // Can call this result => setCharacters(result.data.results), or anything else, just need to be consistent in calling function
        .catch(err => console.log(err))
      
    }
    return (
        <div>
            <button onClick = {Fetch}>Fetch Pokemon</button>
            <br/>
            {/* Use map to trasnform array of Pokemon from API into an array of list elements <li> with a key reference of it's index value and a display property of their name  */}
            <ul>
            {characters.map((pokemon, index) => (
                <li key = {index}> 
                    {pokemon.name}
                </li>
                
            ))}
            </ul>
        </div>
    )
}


export default Pokemon;